
**************************************************************************
              ReadMe file for Campus Safety and Security 2017
                                          
              Prepared by IT Innovative Solutions - Jan 31, 2018 
**************************************************************************


Crime2017EXCEL.zip contains the following files:

        Noncampusarrest141516.xls           -- noncampus arrest data for year 2014, year 2015 and 2016
        Noncampuscrime141516.xls            -- noncampus criminal offenses data for year 2014, year 2015 and 2016
        Noncampusdiscipline141516.xls       -- noncampus disciplinary actions data for year 2014, year 2015 and 2016
        Noncampushate141516.xlsx            -- noncampus hate crimes data for year 2014, year 2015 and 2016
        Noncampusvawa141516.xls             -- noncampus vawa offenses data for year 2014, year 2015 and 2016
        Oncampusarrest141516.xls            -- on-campus arrest data for year 2014, year 2015 and 2016
        Oncampuscrime141516.xls             -- on-campus criminal offenses data for year 2014, year 2015 and 2016
        Oncampusdiscipline141516.xls        -- on-campus disciplinary actions data for year 2014, year 2015 and 2016
        Oncampushate141516.xlsx             -- on-campus hate crimes data for year 2014, year 2015 and 2016
        Oncampusvawa141516.xls              -- on-campus vawa offenses data for year 2014, year 2015 and 2016
        Publicpropertyarrest141516.xls      -- public property arrest data for year 2014, year 2015 and 2016
        Publicpropertycrime141516.xls       -- public property criminal offenses data for year 2014, year 2015 and 2016
        Publicpropertydiscipline141516.xls  -- public property disciplinary actions data for year 2014, year 2015 and 2016
        Publicpropertyhate141516.xlsx       -- public property hate crimes data for year 2014, year 2015 and 2016
        Publicpropertyvawa141516.xls        -- public property vawa offenses data for year 2014, year 2015 and 2016
        Reportedarrest141516.xls            -- reported by local police arrest data for year 2014, year 2015 and 2016
        Reportedcrime141516.xls             -- reported by local police criminal offenses data for year 2014, year 2015 and 2016
        Reporteddiscipline141516.xls        -- reported by local police disciplinary actions data for year 2014, year 2015 and 2016
        Reportedhate141516.xlsx             -- reported by local police hate crimes data for year 2014, year 2015 and 2016
        Reportedvawa141516.xls              -- reported by local police vawa offenses data for year 2014, year 2015 and 2016
        Residencehallarrest141516.xls       -- residence hall arrest data for year 2014, year 2015 and 2016
        Residencehallcrime141516.xls        -- residence hall criminal offenses data for year 2014, year 2015 and 2016
        Residencehalldiscipline141516.xls   -- residence hall disciplinary actions data for year 2014, year 2015 and 2016
        Residencehallhate141516.xlsx        -- residence hall hate crimes data for year 2014, year 2015 and 2016
        Residencehallvawa141516.xls         -- residence hall vawa offenses data for year 2014, year 2015 and 2016
	Residencehallfire14.xls             -- residence hall fire data for year 2014
        Residencehallfire15.xls             -- residence hall fire data for year 2015
	Residencehallfire16.xls             -- residence hall fire data for year 2016
	Unfounded141516.xls                 -- unfounded crimes data for year 2014, year 2015 and 2016
	
      

Data Dictionaries for Each Excel File
        Noncampusarrest141516_Doc.doc         
        Noncampuscrime141516_Doc.doc                  
        Noncampusdiscipline141516_Doc.doc             
        Noncampushate141516_Doc.doc                   
        Noncampusvawa141516_Doc.doc                   
        Oncampusarrest141516_Doc.doc                  
        Oncampuscrime141516_Doc.doc                   
        Oncampusdiscipline141516_Doc.doc              
        Oncampushate141516_Doc.doc                    
        Oncampusvawa141516_Doc.doc                    
        Publicpropertyarrest141516_Doc.doc            
        Publicpropertycrime141516_Doc.doc             
        Publicpropertydiscipline141516_Doc.doc        
        Publicpropertyhate141516_Doc.doc              
        Publicpropertyvawa141516_Doc.doc              
        Reportedarrest141516_Doc.doc                  
        Reportedcrime141516_Doc.doc                   
        Reporteddiscipline141516_Doc.doc              
        Reportedhate141516_Doc.doc                    
        Reportedvawa141516_Doc.doc                    
        Residencehallarrest141516_Doc.doc             
        Residencehallcrime141516_Doc.doc              
        Residencehalldiscipline141516_Doc.doc         
        Residencehallhate141516_Doc.doc               
        Residencehallvawa141516_Doc.doc               
	Residencehallfire13_Doc.doc                   
        Residencehallfire14_Doc.doc                   
	Residencehallfire15_Doc.doc                   
	Unfounded141516_Doc.doc                       
        
           
   __________________________________________________________________________ 

